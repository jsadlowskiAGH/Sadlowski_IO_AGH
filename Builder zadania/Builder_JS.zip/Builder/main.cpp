#include "Pizza.cpp"
#include "Computer.cpp"
#include <iostream>

int main() {
    //Computer Builder
    DesktopComputerBuilder desktopBuilder;
    ComputerAssembler assembler;
    Computer desktop = assembler.assembleComputer(desktopBuilder);
    Computer desktop2 = assembler.assembleComputer2(desktopBuilder);

    std::cout << "Desktop Computer1 Configuration:" << std::endl;
    desktop.display();
    std::cout << "Desktop Computer2 Configuration:" << std::endl;
    desktop2.display();
    std::cout << "\n\n";

    //Pizza Builder
    Cook cook;
    HawaiianPizzaBuilder hawaiianBuilder;
    cook.makePizza(hawaiianBuilder);
    Pizza hawaiianPizza = hawaiianBuilder.getPizza();
    hawaiianPizza.displayPizza();
    SpicyPizzaBuilder spicyBuilder;
    cook.makePizza(spicyBuilder);
    Pizza spicyPizza = spicyBuilder.getPizza();
    spicyPizza.displayPizza();
    CappriciosaPizzaBuilder cappriciosaBuilder;
    cook.makePizza(cappriciosaBuilder);
    Pizza cappriciosaPizza = cappriciosaBuilder.getPizza();
    cappriciosaPizza.displayPizza();
    return 0;
}
